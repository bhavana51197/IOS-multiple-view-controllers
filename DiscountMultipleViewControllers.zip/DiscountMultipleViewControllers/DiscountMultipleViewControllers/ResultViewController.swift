//
//  ResultViewController.swift
//  DiscountMultipleViewControllers
//
//  Created by Annem,Venkata Bhavana on 3/22/22.
//

import UIKit

class ResultViewController: UIViewController {
    
    @IBOutlet weak var enterAmount: UILabel!
    
    @IBOutlet weak var enterDiscRate: UILabel!
    
    @IBOutlet weak var priceAfterDiscRate: UILabel!
    
    var amount = ""
    
    var discRate = ""
    
    var priceAfterDiscount = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        enterAmount.text = enterAmount.text! + amount
        
        enterDiscRate.text = enterDiscRate.text! + discRate
        
        priceAfterDiscRate.text = priceAfterDiscRate.text! + priceAfterDiscount

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
