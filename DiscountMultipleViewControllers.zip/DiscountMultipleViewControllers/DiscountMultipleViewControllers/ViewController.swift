//
//  ViewController.swift
//  DiscountMultipleViewControllers
//
//  Created by Annem,Venkata Bhavana on 3/22/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var amount: UITextField!
    
    @IBOutlet weak var discountRate: UITextField!
    
    var price = 0.0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func calDiscountButton(_ sender: UIButton) {
        //Read the data and convert it to double
        
        var amt = Double(amount.text!)
        
        var discountRate = Double(discountRate.text!)
        
        price = amt! - ((amt!*discountRate!)/100);
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var transition  = segue.identifier
        if transition == "ResultSegue"{
            var destination = segue.destination as! ResultViewController
            destination.amount = amount.text!
            destination.discRate = discountRate.text!
            destination.priceAfterDiscount = String(price)
        }
    }
    
}

